REKLAMUJ TO — VYLEPŠENÁ VERZE

1. V repozitáři GitHub otevři Add file → Upload files.
2. Nahraj tento index.html do kořenové složky repozitáře.
3. Pokud se zobrazí, že soubor už existuje, potvrď nahrazení / aktualizaci.
4. Klikni na Commit changes.
5. Počkej 1–3 minuty a otevři https://antonioferenc75-beep.github.io/reklamuj-to/

Soubor vytváří návrh zprávy přímo v prohlížeči. Formulář nic neposílá na server.
