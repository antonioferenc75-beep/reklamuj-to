REKLAMUJ TO — STARTOVACÍ BALÍČEK

Obsah:
- index.html: mobilní webový prototyp s výběrem problému a generátorem návrhu zprávy
- social_media_plan.txt: návrhy bio, příspěvků, krátkého videa a týdenního plánu

Jak otevřít na mobilu:
1. Rozbal ZIP v telefonu.
2. Otevři index.html v prohlížeči nebo ho pošli do počítače.
3. Pro veřejné zveřejnění nahraj index.html na hosting, který dovoluje statické stránky zdarma (například GitHub Pages). Publikování vyžaduje vlastní účet a několik kroků.
4. Po zveřejnění otestuj odkazy a generátor zpráv na mobilu.

Limity a bezpečnost:
- Web nic neodesílá na server a nezpracovává skutečné reklamace.
- Vzory jsou obecné, nejsou právní radou a negarantují výsledek.
- Ověř aktuální právní informace u oficiálních zdrojů.
- Nejde o státní službu ani advokátní kancelář.
- Název a uživatelská jména jsou pracovní; před použitím ověř dostupnost a případné kolize.
- Sociální účty nejsou založené a příspěvky nejsou zveřejněné.
